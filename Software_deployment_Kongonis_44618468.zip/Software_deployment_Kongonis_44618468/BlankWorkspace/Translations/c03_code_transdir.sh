# This code will bring up the 4 different translations of chapter 3
cat c03/t0*c03.txt
