#This Script will create the text documents needed for your workspace enmasse
touch t01c05.txt t02c05.txt t03c05.txt t04c05.txt t05c05.txt

