#This Script will create the text documents needed for your workspace enmasse
touch t01c02.txt t02c02.txt t03c02.txt t04c02.txt t05c02.txt

