# This code will bring up the 4 different translations of chapter 5
cat c05/t0*c05.txt
