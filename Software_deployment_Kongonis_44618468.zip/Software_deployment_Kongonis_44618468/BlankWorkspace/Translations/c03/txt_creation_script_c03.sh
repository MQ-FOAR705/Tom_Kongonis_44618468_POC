#This Script will create the text documents needed for your workspace enmasse
touch t01c03.txt t02c03.txt t03c03.txt t04c03.txt t05c03.txt

