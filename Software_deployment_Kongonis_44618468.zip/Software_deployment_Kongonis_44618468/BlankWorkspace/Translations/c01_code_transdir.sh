# This code will bring up the 4 different translations of chapter 1
cat c01/t0*c01.txt



