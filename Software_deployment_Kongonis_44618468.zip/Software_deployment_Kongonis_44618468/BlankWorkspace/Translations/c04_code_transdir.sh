# This code will bring up the 4 different translations of chapter 4
cat c04/t0*c04.txt
