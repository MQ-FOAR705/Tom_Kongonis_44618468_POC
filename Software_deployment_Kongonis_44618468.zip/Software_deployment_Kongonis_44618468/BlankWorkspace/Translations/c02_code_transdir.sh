# This code will bring up the 4 different translations of chapter 2
cat c02/t0*c02.txt

