The codes within all of these directories are directory specific.
This means that if they are moved, they potentially will not work.
I understand that this is a sgnifcant flaw within the code.
However, i would ask that you leave them within the directories,
as they were intended.

Thankyou,

Tom Kongonis
