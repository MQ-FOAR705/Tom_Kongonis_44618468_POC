#This Script will pull all avalable chapters up

cd .. 
cd Translations/ 
cat c01/t0*c01.txt c02/t0*c02.txt c03/t0*c03.txt c04/t0*c04.txt c05/t0*c05.txt
