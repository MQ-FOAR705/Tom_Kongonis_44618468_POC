#This code will access the translations of chapter 1
#its purpose is to do so from the Shell_Script folder
#This will ONLY work from this directory

cd ..
cd Translations/
cat C01/t0*c01.txt

