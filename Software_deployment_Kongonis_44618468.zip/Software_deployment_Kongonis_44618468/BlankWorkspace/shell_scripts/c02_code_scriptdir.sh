#This code will access the translations of chapter 2
#its purpose is to do so from the Shell_Script folder
#This will ONLY work from this directory

cd ..
cd Translations/
cat C02/t0*c02.txt
