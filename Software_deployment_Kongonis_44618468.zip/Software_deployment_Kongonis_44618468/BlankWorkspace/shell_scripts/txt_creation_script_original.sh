#This Script will create the text documents needed for your workspace enmasse
touch t01c01.txt t02c01.txt t03c01.txt t04c01.txt t05c01.txt

